/**
 * hostscript.jsx
 * ExtendScript layer — runs inside Premiere Pro / After Effects.
 * Called from the CEP panel via csInterface.evalScript(...)
 */

/**
 * Opens a native OS file picker filtered to .docx files.
 * Returns the native file-system path, or an empty string if cancelled.
 */
function selectDocxFile() {
  try {
    var file = File.openDialog("Select a Script (.docx)", "*.docx,Word Documents:*.docx");
    if (file && file.exists) {
      return file.fsName;
    }
  } catch (e) {
    return "ERROR:" + e.message;
  }
  return "";
}

/**
 * Returns the name of the currently active host application.
 */
function getHostAppName() {
  try {
    return app.name + " " + app.version;
  } catch (e) {
    return "Adobe App";
  }
}

/**
 * (Premiere Pro only) Creates markers from an array of cue strings.
 * cuesJson = JSON string: [ { time: 0, label: "Scene 1" }, ... ]
 */
function addMarkersFromScript(cuesJson) {
  try {
    var cues = eval("(" + cuesJson + ")");
    var seq = app.project.activeSequence;
    if (!seq) return "ERROR:No active sequence in Premiere Pro.";
    for (var i = 0; i < cues.length; i++) {
      var m = seq.markers.createMarker(cues[i].time);
      m.name = cues[i].label;
      m.comments = cues[i].label;
    }
    return "OK:" + cues.length + " markers added.";
  } catch (e) {
    return "ERROR:" + e.message;
  }
}
