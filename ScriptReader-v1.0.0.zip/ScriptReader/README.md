# Script Reader — Adobe CEP Extension
Read `.docx` script files directly inside **Premiere Pro** and **After Effects**.

## Features
- Open any `.docx` file via native file picker
- Rich formatted view (headings, bold, italic, tables)
- Plain text view with monospace font
- Live search / highlight within the script
- Copy all text to clipboard
- Recent files list (last 8 files)
- **Add PR Markers** — auto-creates timeline markers from scene headings (INT./EXT.)
- Works in both Premiere Pro and After Effects

---

## Installation

### Windows
1. Close Premiere Pro / After Effects
2. Double-click **`INSTALL_WINDOWS.bat`** (right-click → Run as Administrator if prompted)
3. Reopen the app → `Window > Extensions > Script Reader`

### macOS
1. Close Premiere Pro / After Effects
2. Open Terminal, `cd` to this folder, then run:
   ```bash
   chmod +x INSTALL_MAC.sh && ./INSTALL_MAC.sh
   ```
3. Reopen the app → `Window > Extensions > Script Reader`

---

## Manual Install (if scripts don't work)

**Step 1 — Enable unsigned extensions**

*Windows (run as Admin in CMD):*
```
reg add "HKEY_CURRENT_USER\SOFTWARE\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1
```

*macOS (Terminal):*
```bash
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
```
> Repeat for CSXS.9, CSXS.10, CSXS.12 if needed.

**Step 2 — Copy extension folder**

| OS | Path |
|----|------|
| Windows | `%APPDATA%\Adobe\CEP\extensions\ScriptReader\` |
| macOS   | `~/Library/Application Support/Adobe/CEP/extensions/ScriptReader/` |

Copy the entire `ScriptReader` folder (containing `CSXS/`, `js/`, `jsx/`, etc.) into that path.

**Step 3 — Restart the Adobe app**

Go to `Window → Extensions → Script Reader`.

---

## Supported Adobe Apps
| App | Min Version |
|-----|------------|
| Premiere Pro | CC 2019 (v13) and later |
| After Effects | CC 2019 (v16) and later |

---

## Troubleshooting

**Panel doesn't appear in Window menu**
- Make sure `PlayerDebugMode` is set to `1` for your CEP version (try 9–12)
- Verify the folder is named exactly `ScriptReader` and contains `CSXS/manifest.xml`

**File won't load**
- Only `.docx` files are supported (not `.doc`)
- Make sure the file isn't open/locked by another application

**"Add Markers" button is greyed out**
- Open a Sequence in Premiere Pro first (markers require an active sequence)
- The button has no effect in After Effects (PR only feature)
