@echo off
:: Script Reader – Windows Installer
:: Run as Administrator for the registry key

echo ============================================
echo  Script Reader – Adobe CEP Extension Setup
echo ============================================
echo.

:: 1. Enable unsigned extensions (CEP 9–11)
echo [1/3] Enabling debug/unsigned extension mode...
reg add "HKEY_CURRENT_USER\SOFTWARE\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\SOFTWARE\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\SOFTWARE\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\SOFTWARE\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo    Done.

:: 2. Create extension folder
set DEST=%APPDATA%\Adobe\CEP\extensions\ScriptReader
echo [2/3] Installing to %DEST% ...
if exist "%DEST%" (
  echo    Removing old version...
  rmdir /s /q "%DEST%"
)
mkdir "%DEST%"

:: 3. Copy files
xcopy /e /i /q "%~dp0*" "%DEST%\" >nul
echo    Files copied.

echo.
echo [3/3] Done! Restart Premiere Pro or After Effects.
echo       Go to:  Window ^> Extensions ^> Script Reader
echo.
pause
