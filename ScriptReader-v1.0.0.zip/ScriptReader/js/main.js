/* global CSInterface, mammoth */

(function () {
  "use strict";

  // ── Constants ────────────────────────────────────────────────────────────────
  var CURRENT_VERSION   = "1.0.0";
  var GITHUB_USER       = "rupom266";
  var GITHUB_REPO       = "ScriptReader";
  var GITHUB_RELEASE_URL = "https://github.com/" + GITHUB_USER + "/" + GITHUB_REPO + "/releases/latest";
  var VERSION_CHECK_URL  =
    "https://raw.githubusercontent.com/" + GITHUB_USER + "/" + GITHUB_REPO + "/main/version.json";

  // ── State ────────────────────────────────────────────────────────────────────
  var cs             = new CSInterface();
  var currentDocText = "";
  var currentDocHtml = "";
  var currentFileName= "";
  var viewMode       = "rich";
  var searchTerm     = "";

  // ── DOM refs ─────────────────────────────────────────────────────────────────
  var openBtn        = document.getElementById("openBtn");
  var recentBtn      = document.getElementById("recentBtn");
  var markersBtn     = document.getElementById("markersBtn");
  var viewToggle     = document.getElementById("viewToggle");
  var searchInput    = document.getElementById("searchInput");
  var clearSearch    = document.getElementById("clearSearch");
  var copyBtn        = document.getElementById("copyBtn");
  var wordCount      = document.getElementById("wordCount");
  var fileName       = document.getElementById("fileName");
  var content        = document.getElementById("content");
  var toast          = document.getElementById("toast");
  var loadingOverlay = document.getElementById("loadingOverlay");
  var recentList     = document.getElementById("recentList");
  var recentPanel    = document.getElementById("recentPanel");
  // About
  var aboutBtn       = document.getElementById("aboutBtn");
  var aboutOverlay   = document.getElementById("aboutOverlay");
  var aboutClose     = document.getElementById("aboutClose");
  // Update banner
  var updateBanner   = document.getElementById("updateBanner");
  var updateLink     = document.getElementById("updateLink");
  var updateDismiss  = document.getElementById("updateDismiss");

  // ── Init ─────────────────────────────────────────────────────────────────────
  loadRecent();
  checkForUpdate();

  // ── About panel ──────────────────────────────────────────────────────────────
  aboutBtn.addEventListener("click", function () {
    aboutOverlay.classList.toggle("hidden");
  });
  aboutClose.addEventListener("click", function () {
    aboutOverlay.classList.add("hidden");
  });
  aboutOverlay.addEventListener("click", function (e) {
    if (e.target === aboutOverlay) aboutOverlay.classList.add("hidden");
  });

  // ── Update check ─────────────────────────────────────────────────────────────
  function checkForUpdate() {
    fetch(VERSION_CHECK_URL + "?t=" + Date.now())
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data && data.version && isNewer(data.version, CURRENT_VERSION)) {
          updateLink.href = GITHUB_RELEASE_URL;
          updateLink.textContent = "Download v" + data.version + " on GitHub";
          updateBanner.classList.remove("hidden");
        }
      })
      .catch(function () { /* silently fail — no internet or repo not set up yet */ });
  }

  function isNewer(remote, current) {
    var r = remote.split(".").map(Number);
    var c = current.split(".").map(Number);
    for (var i = 0; i < 3; i++) {
      if ((r[i] || 0) > (c[i] || 0)) return true;
      if ((r[i] || 0) < (c[i] || 0)) return false;
    }
    return false;
  }

  updateDismiss.addEventListener("click", function () {
    updateBanner.classList.add("hidden");
  });

  // ── Open file ────────────────────────────────────────────────────────────────
  openBtn.addEventListener("click", function () {
    cs.evalScript("selectDocxFile()", function (path) {
      if (!path || path === "undefined" || path === "") return;
      if (path.indexOf("ERROR:") === 0) {
        showToast("⚠ " + path.replace("ERROR:", ""), true);
        return;
      }
      loadDocx(path);
    });
  });

  // ── Recent files ─────────────────────────────────────────────────────────────
  recentBtn.addEventListener("click", function () {
    recentPanel.classList.toggle("hidden");
  });

  function loadRecent() {
    var stored = localStorage.getItem("sr_recent");
    var files  = stored ? JSON.parse(stored) : [];
    recentList.innerHTML = "";
    if (files.length === 0) {
      recentList.innerHTML = '<div class="empty-recent">No recent files.</div>';
      return;
    }
    files.forEach(function (f) {
      var item = document.createElement("div");
      item.className = "recent-item";
      item.title = f.path;
      item.innerHTML =
        '<span class="ri-name">' + f.name + "</span>" +
        '<span class="ri-path">' + shortenPath(f.path) + "</span>";
      item.addEventListener("click", function () {
        recentPanel.classList.add("hidden");
        loadDocx(f.path);
      });
      recentList.appendChild(item);
    });
  }

  function saveRecent(path, name) {
    var stored = localStorage.getItem("sr_recent");
    var files  = stored ? JSON.parse(stored) : [];
    files = files.filter(function (f) { return f.path !== path; });
    files.unshift({ path: path, name: name });
    if (files.length > 8) files = files.slice(0, 8);
    localStorage.setItem("sr_recent", JSON.stringify(files));
    loadRecent();
  }

  function shortenPath(p) {
    if (p.length < 48) return p;
    return "…" + p.slice(-45);
  }

  // ── Load & parse .docx ───────────────────────────────────────────────────────
  function loadDocx(path) {
    showLoading(true);
    recentPanel.classList.add("hidden");

    var url = path.replace(/\\/g, "/");
    if (url.indexOf("/") === 0)      url = "file://" + url;
    if (url.indexOf("file://") !== 0) url = "file://" + url;

    fetch(url)
      .then(function (r) {
        if (!r.ok) throw new Error("Cannot read file (HTTP " + r.status + ")");
        return r.arrayBuffer();
      })
      .then(function (buffer) {
        return Promise.all([
          mammoth.convertToHtml({ arrayBuffer: buffer }),
          mammoth.extractRawText({ arrayBuffer: buffer })
        ]);
      })
      .then(function (results) {
        currentDocHtml  = results[0].value;
        currentDocText  = results[1].value;
        currentFileName = path.split(/[\\/]/).pop();

        fileName.textContent = currentFileName;
        updateWordCount();
        renderContent();
        saveRecent(path, currentFileName);
        showToast("✔ Script loaded");
        showLoading(false);

        markersBtn.disabled  = false;
        viewToggle.disabled  = false;
        copyBtn.disabled     = false;
        searchInput.disabled = false;
      })
      .catch(function (err) {
        showLoading(false);
        showToast("⚠ " + err.message, true);
        content.innerHTML =
          '<p class="error-msg">Could not load file.<br><small>' + err.message + "</small></p>";
      });
  }

  // ── Render ───────────────────────────────────────────────────────────────────
  function renderContent() {
    searchTerm = searchInput.value.trim();
    if (viewMode === "plain") {
      var escaped = escapeHtml(currentDocText);
      if (searchTerm) escaped = highlight(escaped, searchTerm);
      content.innerHTML = '<pre class="plain-text">' + escaped + "</pre>";
    } else {
      var html = currentDocHtml;
      if (searchTerm) html = highlightHtml(html, searchTerm);
      content.innerHTML = html;
    }
    content.scrollTop = 0;
  }

  // ── View toggle ──────────────────────────────────────────────────────────────
  viewToggle.addEventListener("click", function () {
    if (!currentDocHtml) return;
    viewMode = viewMode === "rich" ? "plain" : "rich";
    viewToggle.textContent = viewMode === "rich" ? "Plain Text" : "Rich View";
    renderContent();
  });

  // ── Search ───────────────────────────────────────────────────────────────────
  searchInput.addEventListener("input", debounce(function () {
    clearSearch.classList.toggle("hidden", !searchInput.value);
    if (currentDocHtml) renderContent();
  }, 200));

  clearSearch.addEventListener("click", function () {
    searchInput.value = "";
    clearSearch.classList.add("hidden");
    if (currentDocHtml) renderContent();
  });

  function highlight(text, term) {
    var re = new RegExp("(" + escapeRegex(term) + ")", "gi");
    return text.replace(re, "<mark>$1</mark>");
  }

  function highlightHtml(html, term) {
    var tmp = document.createElement("div");
    tmp.innerHTML = html;
    walkText(tmp, term);
    return tmp.innerHTML;
  }

  function walkText(node, term) {
    if (node.nodeType === 3) {
      var re = new RegExp("(" + escapeRegex(term) + ")", "gi");
      if (re.test(node.nodeValue)) {
        var span = document.createElement("span");
        span.innerHTML = node.nodeValue.replace(re, "<mark>$1</mark>");
        node.parentNode.replaceChild(span, node);
      }
    } else if (node.nodeType === 1 && node.nodeName !== "MARK") {
      Array.from(node.childNodes).forEach(function (c) { walkText(c, term); });
    }
  }

  // ── Copy ─────────────────────────────────────────────────────────────────────
  copyBtn.addEventListener("click", function () {
    if (!currentDocText) return;
    navigator.clipboard.writeText(currentDocText)
      .then(function () { showToast("✔ Text copied to clipboard"); })
      .catch(function () {
        var ta = document.createElement("textarea");
        ta.value = currentDocText;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
        showToast("✔ Text copied");
      });
  });

  // ── PR Markers ───────────────────────────────────────────────────────────────
  markersBtn.addEventListener("click", function () {
    if (!currentDocText) return;
    var lines = currentDocText.split("\n").filter(function (l) {
      return l.trim().match(/^(INT\.|EXT\.|SCENE|ACT |CHAPTER |\d+\.)/i);
    });
    if (lines.length === 0) {
      showToast("No scene headings found to create markers.", true);
      return;
    }
    var cues = lines.map(function (l, i) {
      return { time: i * 30, label: l.trim().slice(0, 60) };
    });
    var json = JSON.stringify(cues).replace(/"/g, '\\"');
    cs.evalScript('addMarkersFromScript("' + json + '")', function (result) {
      if (result && result.indexOf("OK:") === 0) {
        showToast("✔ " + result.replace("OK:", ""));
      } else {
        showToast("⚠ " + (result || "Unknown error").replace("ERROR:", ""), true);
      }
    });
  });

  // ── Helpers ──────────────────────────────────────────────────────────────────
  function updateWordCount() {
    var words = currentDocText.trim().split(/\s+/).filter(Boolean).length;
    var chars = currentDocText.length;
    wordCount.textContent =
      words.toLocaleString() + " words · " + chars.toLocaleString() + " chars";
  }

  function showLoading(on) {
    loadingOverlay.classList.toggle("hidden", !on);
  }

  function showToast(msg, isError) {
    toast.textContent = msg;
    toast.className   = "toast" + (isError ? " error" : "");
    toast.classList.remove("hidden");
    setTimeout(function () { toast.classList.add("hidden"); }, 3000);
  }

  function escapeHtml(s) {
    return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  }

  function escapeRegex(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function debounce(fn, ms) {
    var t;
    return function () { clearTimeout(t); t = setTimeout(fn, ms); };
  }

})();
