#!/bin/bash
# Script Reader – macOS Installer

echo "============================================"
echo " Script Reader – Adobe CEP Extension Setup"
echo "============================================"
echo ""

DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/ScriptReader"

# 1. Enable unsigned extensions for CEP versions 9–12
echo "[1/3] Enabling unsigned extension mode..."
for v in 9 10 11 12; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1 2>/dev/null
done
echo "   Done."

# 2. Install extension
echo "[2/3] Installing to: $DEST"
rm -rf "$DEST"
mkdir -p "$DEST"

# Copy all files from the script's directory
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp -R "$SCRIPT_DIR/." "$DEST/"
echo "   Files copied."

echo ""
echo "[3/3] Done! Restart Premiere Pro or After Effects."
echo "       Go to:  Window > Extensions > Script Reader"
echo ""
